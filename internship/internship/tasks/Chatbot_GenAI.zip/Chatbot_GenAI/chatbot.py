import os
import base64
import streamlit as st
from google import genai
from dotenv import load_dotenv

# ---------------- LOAD ENV ----------------
load_dotenv()
api_key = os.getenv("geminiapi_key")

if not api_key:
    st.error("❌ API key not found")
    st.stop()

# ✅ Gemini Client
client = genai.Client(api_key=api_key)

# ---------------- PAGE CONFIG ----------------
st.set_page_config(
    page_title="AI Career & Interview Coach",
    page_icon="💼",
    layout="centered"
)

# ---------------- BACKGROUND IMAGE ----------------
def set_bg_image(image_path):
    with open(image_path, "rb") as img:
        encoded = base64.b64encode(img.read()).decode()

    st.markdown(f"""
    <style>
    .stApp {{
        background-image: url("data:image/jpg;base64,{encoded}");
        background-size: cover;
        background-position: center;
    }}

    /* HEADER */
    .header-box {{
        background: rgba(255,255,255,0.88);
        backdrop-filter: blur(10px);
        padding: 25px;
        border-radius: 20px;
        text-align: center;
        width: 80%;
        margin: 40px auto;
        box-shadow: 0px 8px 25px rgba(0,0,0,0.2);
    }}

    .title {{
        font-size: 28px;
        font-weight: bold;
        color: black;
    }}

    .subtitle {{
        font-size: 14px;
        color: #444;
        margin-top: 5px;
    }}

    /* CHAT BOX */
    .chat-box {{
        background-color: rgba(255,255,255,0.9);
        padding: 20px;
        border-radius: 15px;
    }}

    .user-msg {{
        background-color: #e7f3ff;
        color: black;
        padding: 10px;
        border-radius: 10px;
        margin-bottom: 8px;
    }}

    .bot-msg {{
        background-color: #e8f5e9;
        color: black;
        padding: 10px;
        border-radius: 10px;
        margin-bottom: 8px;
    }}

    /* INPUT CENTER */
    .stChatFloatingInputContainer {{
        width: 70% !important;
        margin: auto !important;
        left: 0;
        right: 0;
        bottom: 40px !important;
    }}

    .stChatFloatingInputContainer textarea {{
        border-radius: 25px !important;
        padding: 12px !important;
        background: white !important;
        color: black !important;
        font-size: 15px !important;
    }}
    </style>
    """, unsafe_allow_html=True)

# 👉 Your background image file
set_bg_image("image.jpeg")

# ---------------- HEADER ----------------
st.markdown("""
<div class="header-box">
    <div class="title">💼 AI Career & Interview Coach</div>
    <div class="subtitle">Career guidance | Resume help | Mock interviews</div>
</div>
""", unsafe_allow_html=True)

# ---------------- SESSION ----------------
if "messages" not in st.session_state:
    st.session_state.messages = []

if "user_name" not in st.session_state:
    st.session_state.user_name = None

# ---------------- SYSTEM PROMPT ----------------
system_prompt = """
You are an AI Career & Interview Coach.

- Help with career guidance
- Suggest learning paths (AI, Data Science, Web Dev)
- Conduct mock interviews
- Give resume tips
- Suggest projects
- Help with LinkedIn and job search

Rules:
- Be professional and helpful
- Keep answers structured and clear
- Ask follow-up questions
- If question is unrelated, reply:
"I'm designed to help with career guidance and interview preparation."
"""

# ---------------- DISPLAY CHAT ----------------
st.markdown("<div class='chat-box'>", unsafe_allow_html=True)

for role, text in st.session_state.messages:
    if role == "user":
        st.markdown(f"<div class='user-msg'><b>You:</b> {text}</div>", unsafe_allow_html=True)
    else:
        st.markdown(f"<div class='bot-msg'><b>Coach:</b> {text}</div>", unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)

# ---------------- USER INPUT ----------------
user_input = st.chat_input("Ask about careers, skills, or interviews...")

if user_input:
    st.session_state.messages.append(("user", user_input))

    # Capture name
    if st.session_state.user_name is None and "my name is" in user_input.lower():
        st.session_state.user_name = user_input.split()[-1].capitalize()

    try:
        full_prompt = system_prompt + "\nUser: " + user_input

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=full_prompt
        )

        bot_reply = response.text

    except Exception as e:
        bot_reply = f"❌ Error: {str(e)}"

    # Personalization
    if st.session_state.user_name:
        bot_reply = bot_reply.replace("Hello", f"Hello {st.session_state.user_name}")

    st.session_state.messages.append(("bot", bot_reply))
    st.rerun()
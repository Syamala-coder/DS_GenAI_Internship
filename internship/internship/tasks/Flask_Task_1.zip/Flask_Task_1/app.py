from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def home():
    name = request.args.get("name")

    if name:
        return name.upper()
    else:
        return "<h1>Please enter name in URL</h1>"

if __name__ == "__main__":
    app.run(debug=True)



   



from flask import Flask, render_template, request
import re

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    matches = []
    error = None

    if request.method == "POST":
        text = request.form.get("text")
        pattern = request.form.get("pattern")

        try:
            matches = re.findall(pattern, text)
        except re.error as e:
            error = f"Invalid Regex Pattern: {e}"

    return render_template("index.html", matches=matches, error=error)

if __name__ == "__main__":
    app.run(debug=True)

from flask import Flask, render_template, request, redirect, url_for, session
from models import db, URL, User
import string
import random
import validators

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'your_secret_key'

db.init_app(app)

# Create DB
with app.app_context():
    db.create_all()


# 🔢 Generate unique short code
def generate_short_code(length=6):
    characters = string.ascii_letters + string.digits
    while True:
        short_code = ''.join(random.choice(characters) for _ in range(length))
        existing = URL.query.filter_by(short_code=short_code).first()
        if not existing:
            return short_code


# ---------------- AUTH ---------------- #

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # 🔴 Username length validation (EXACT MESSAGE)
        if len(username) < 5 or len(username) > 9:
            return render_template(
                'signup.html',
                error="Username must be between 5 to 9 characters long"
            )

        # 🔴 Duplicate username check (EXACT MESSAGE)
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return render_template(
                'signup.html',
                error="This username already exists..."
            )

        # ✅ Create user
        user = User(username=username, password=password)
        db.session.add(user)
        db.session.commit()

        return redirect('/login')

    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username, password=password).first()

        if user:
            session['user'] = username
            return redirect('/')
        else:
            return render_template(
                'login.html',
                error="Invalid username or password"
            )

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/login')


# ---------------- HOME ---------------- #

@app.route('/', methods=['GET', 'POST'])
def home():
    if 'user' not in session:
        return redirect('/login')

    short_url = None

    if request.method == 'POST':
        original_url = request.form.get('url')

        # 🔴 URL validation
        if not validators.url(original_url):
            return render_template(
                'home.html',
                short_url=None,
                error="Invalid URL"
            )

        short_code = generate_short_code()

        # 🔥 Get current user
        user = User.query.filter_by(username=session['user']).first()

        # 🔥 Save URL with user_id
        new_url = URL(
            original_url=original_url,
            short_code=short_code,
            user_id=user.id
        )

        db.session.add(new_url)
        db.session.commit()

        short_url = request.host_url + short_code

    return render_template('home.html', short_url=short_url)


# ---------------- REDIRECT ---------------- #

@app.route('/<short_code>')
def redirect_url(short_code):
    url = URL.query.filter_by(short_code=short_code).first()

    if url:
        return redirect(url.original_url)

    return "URL not found"


# ---------------- HISTORY ---------------- #

@app.route('/history')
def history():
    if 'user' not in session:
        return redirect('/login')

    user = User.query.filter_by(username=session['user']).first()
    urls = URL.query.filter_by(user_id=user.id).all()

    return render_template('history.html', urls=urls)


# ---------------- RUN ---------------- #

if __name__ == '__main__':
    app.run(debug=True)
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# 👤 User Table
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

    # 🔗 Relationship (optional but good practice)
    urls = db.relationship('URL', backref='user', lazy=True)


# 🔗 URL Table
class URL(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    original_url = db.Column(db.String(500), nullable=False)
    short_code = db.Column(db.String(10), unique=True, nullable=False)

    # ✅ NEW FIELD (IMPORTANT)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
